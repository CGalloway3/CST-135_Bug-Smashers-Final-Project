//CST-135 group assignment for Topic 2, a collaboration of Richard Boyd, Chad Galloway, and Dennis Witt
/**  Program: Vending Machine
*    File: main.java
*    Summary: Driver class for functionality testing.
*    Author: Richard Boyd
*    Date: March 30th, 2018
**/

package vendingmachine;

class Main {

	public static void main(String[] args) {
		
		Dispenser main = new Dispenser();
		main.displayProducts();
	}


}
