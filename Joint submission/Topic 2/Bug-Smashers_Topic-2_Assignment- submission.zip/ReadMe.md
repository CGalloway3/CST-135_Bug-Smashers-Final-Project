Assignment submission material for Topic 2 CST-135
